# enter your code here to solve the housing assignment
# voer hier je code in om de huisvestingsvraag op te lossen